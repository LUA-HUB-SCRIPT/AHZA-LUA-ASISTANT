import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const AhzaApp());

class AhzaApp extends StatelessWidget {
  const AhzaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'AHZA ASISTANT',
    debugShowCheckedModeBanner: false,
    theme: ThemeData.dark(useMaterial3: true).copyWith(
      scaffoldBackgroundColor: const Color(0xFF080B13),
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF00E5FF), brightness: Brightness.dark),
    ),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final stt.SpeechToText speech = stt.SpeechToText();
  final FlutterTts tts = FlutterTts();
  final TextEditingController command = TextEditingController();
  bool listening = false;
  String status = 'Siap membantu. Tekan mikrofon atau ketik perintah.';
  int colorIndex = 0;
  final colors = const [Color(0xFF00E5FF), Color(0xFFB388FF), Color(0xFFFF4081), Color(0xFF69F0AE), Color(0xFFFFD740), Color(0xFFFF6E40)];

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      if (mounted) setState(() => colorIndex = p.getInt('colorIndex') ?? 0);
    });
    tts.setLanguage('id-ID');
  }

  Future<void> say(String text) async { await tts.speak(text); }
  Future<void> listen() async {
    final available = await speech.initialize(onStatus: (s) { if (mounted) setState(() => listening = s == 'listening'); },
      onError: (e) { if (mounted) setState(() => status = 'Suara tidak tersedia: ${e.errorMsg}'); });
    if (!available) { setState(() => status = 'Pengenalan suara tidak tersedia di perangkat ini.'); return; }
    setState(() { listening = true; status = 'Mendengarkan...'; });
    await speech.listen(localeId: 'id_ID', onResult: (r) {
      if (r.finalResult) { command.text = r.recognizedWords; runCommand(r.recognizedWords); }
    });
  }

  Future<void> runCommand(String raw) async {
    final s = raw.toLowerCase().trim();
    setState(() => status = 'Perintah: $raw');
    if (s.contains('emergency') || s.contains('darurat')) {
      await say('Membuka pilihan bantuan darurat. Pastikan situasi benar-benar darurat.');
      if (mounted) showEmergency();
    } else if (s.contains('polisi')) { await say('Membuka panggilan polisi'); await callNumber('110'); }
    else if (s.contains('ambulans') || s.contains('ambulan')) { await say('Membuka panggilan layanan kesehatan darurat'); await callNumber('119'); }
    else if (s.contains('damkar') || s.contains('kebakaran')) { await say('Membuka panggilan pemadam kebakaran'); await callNumber('113'); }
    else if (s.contains('warna') || s.contains('rgb')) { setState(() => colorIndex = (colorIndex + 1) % colors.length); final p=await SharedPreferences.getInstance(); await p.setInt('colorIndex', colorIndex); await say('Warna tema diganti'); }
    else if (s.contains('jam')) { await say('Sekarang ${TimeOfDay.now().format(context)}'); }
    else { await say('Perintah belum tersedia. Coba emergency, polisi, ambulans, damkar, atau ganti warna.'); }
  }

  Future<void> callNumber(String number) async {
    final uri = Uri(scheme: 'tel', path: number);
    if (await canLaunchUrl(uri)) await launchUrl(uri);
    else if (mounted) setState(() => status = 'Tidak dapat membuka dialer. Silakan hubungi $number secara manual.');
  }

  void showEmergency() {
    showModalBottomSheet(context: context, backgroundColor: const Color(0xFF171D2B), builder: (ctx) => SafeArea(
      child: Padding(padding: const EdgeInsets.all(20), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Text('EMERGENCY CENTER', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8), const Text('Pilih layanan. Panggilan akan dibuka di aplikasi telepon; periksa nomor dan konfirmasi sebelum menelepon. Ketersediaan 112 berbeda menurut daerah.'),
        const SizedBox(height: 14),
        for (final item in [('Darurat umum — 112','112'),('Polisi — 110','110'),('Ambulans / kesehatan — 119','119'),('Pemadam kebakaran — 113','113')])
          Padding(padding: const EdgeInsets.only(bottom: 8), child: FilledButton.icon(onPressed: () { Navigator.pop(ctx); callNumber(item.$2); }, icon: const Icon(Icons.call), label: Text(item.$1))),
      ])),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final accent = colors[colorIndex];
    return Scaffold(
      appBar: AppBar(title: const Text('AHZA ASISTANT'), actions: [IconButton(tooltip:'Ganti warna', onPressed: () async { setState(() => colorIndex=(colorIndex+1)%colors.length); final p=await SharedPreferences.getInstance(); await p.setInt('colorIndex',colorIndex); }, icon: Icon(Icons.palette, color: accent))]),
      body: SafeArea(child: ListView(padding: const EdgeInsets.all(18), children: [
        Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(borderRadius: BorderRadius.circular(28), border: Border.all(color: accent.withOpacity(.65)), gradient: LinearGradient(colors: [accent.withOpacity(.18), const Color(0xFF171D2B)])),
          child: Column(children: [
            Icon(Icons.graphic_eq, size: 68, color: accent),
            const SizedBox(height: 12), const Text('ASSISTANT ONLINE', style: TextStyle(letterSpacing: 2, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8), Text(status, textAlign: TextAlign.center),
            const SizedBox(height: 18),
            FilledButton.icon(onPressed: listening ? () async { await speech.stop(); setState(()=>listening=false); } : listen, icon: Icon(listening ? Icons.stop : Icons.mic), label: Text(listening ? 'STOP LISTENING' : 'TAP TO SPEAK')),
          ])),
        const SizedBox(height: 18),
        TextField(controller: command, onSubmitted: runCommand, decoration: InputDecoration(hintText:'Ketik perintah...', suffixIcon: IconButton(icon: const Icon(Icons.send), onPressed:()=>runCommand(command.text)), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)))),
        const SizedBox(height: 20),
        const Text('QUICK ACTIONS', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.4)),
        const SizedBox(height: 12),
        GridView.count(shrinkWrap:true, physics: const NeverScrollableScrollPhysics(), crossAxisCount:2, mainAxisSpacing:10, crossAxisSpacing:10, childAspectRatio:1.55, children:[
          action('Emergency Center', Icons.sos, Colors.red, showEmergency),
          action('Ganti RGB', Icons.color_lens, accent, ()=>runCommand('ganti warna')),
          action('Ucapkan Jam', Icons.access_time, accent, ()=>runCommand('jam')),
          action('Bantuan', Icons.help_outline, accent, ()=>showHelp()),
        ]),
        const SizedBox(height: 16),
        const Text('Warna tema mengubah aksen aplikasi. RGB tepi sistem/overlay membutuhkan izin khusus dan belum diaktifkan pada build dasar.', style: TextStyle(color: Colors.white60, fontSize: 12)),
      ])),
    );
  }

  Widget action(String label, IconData icon, Color color, VoidCallback onTap) => Card(color: const Color(0xFF151B29), child: InkWell(borderRadius: BorderRadius.circular(16), onTap:onTap, child: Center(child: Column(mainAxisSize:MainAxisSize.min, children:[Icon(icon,color:color,size:28), const SizedBox(height:8), Text(label, textAlign:TextAlign.center)]))));
  void showHelp() => showAboutDialog(context:context, applicationName:'AHZA ASISTANT', applicationVersion:'1.0.0', children:[const Text('Asisten komunitas dengan perintah suara, tema, dan akses cepat layanan darurat. Gunakan layanan darurat hanya untuk keadaan sebenarnya.')]);
  @override
  void dispose() { speech.stop(); tts.stop(); command.dispose(); super.dispose(); }
}
