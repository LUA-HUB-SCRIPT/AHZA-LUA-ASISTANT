# Run from a Windows PowerShell terminal in this project directory.
flutter config --enable-windows-desktop
flutter create --platforms=windows .
flutter pub get
flutter build windows --release
Write-Host 'Build output: build\windows\x64\runner\Release\'
