# AHZA ASISTANT

Community assistant starter project (Flutter) for Android and Windows.

## Included in this source
- Modern dark dashboard and selectable accent colors
- Speech-to-text and text-to-speech (device/platform availability varies)
- Typed/voice commands: emergency, polisi, ambulans, damkar, ganti warna, jam
- Emergency dialer shortcuts: 112, 110, 119, 113
- Local preference for accent color

## Build
Install Flutter SDK and Android Studio / Android SDK.

```bash
flutter pub get
flutter run
flutter build apk --release
```

For Windows, use Windows with Flutter desktop enabled:
```powershell
flutter config --enable-windows-desktop
flutter create --platforms=windows .
flutter pub get
flutter run -d windows
flutter build windows --release
```

The Windows build output is under `build/windows/x64/runner/Release/`.

## Important
This is a functional starter, not a claim that all 100 planned features are implemented. Emergency actions open the dialer; confirm before placing a call. Emergency number availability varies by location. Speech recognition may require platform permissions or network services. Do not use the script/plugin area for untrusted code; this starter does not execute arbitrary scripts or modify other apps.
