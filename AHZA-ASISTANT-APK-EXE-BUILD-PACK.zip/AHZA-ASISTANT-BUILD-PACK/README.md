# AHZA ASISTANT

Build-ready Flutter starter for Android and Windows. The GitHub Actions workflow compiles:
- Android release APK
- Windows Release app bundle (ZIP containing the EXE and required runtime files)

## GitHub upload
Upload the contents of this folder to the root of your repository, including `.github/workflows/build.yml`.

Then open **Actions → Build AHZA ASISTANT (APK + EXE) → Run workflow**. Download the two artifacts after both jobs succeed.

The Windows ZIP includes the EXE and companion files; keep them together when running the app.

This is a functional starter app, not a finished 100-feature assistant. The emergency panel displays reference numbers but does not place calls.
