import 'package:flutter/material.dart';

void main() => runApp(const AhzaApp());

class AhzaApp extends StatelessWidget {
  const AhzaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AHZA ASISTANT',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF00E5C3),
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: const Color(0xFF08111F),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController _controller = TextEditingController();
  String _response = 'Halo! Aku AHZA ASISTANT. Pilih alat atau ketik perintah.';
  String _accent = 'Mint';

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _runCommand([String? value]) {
    final command = (value ?? _controller.text).trim().toLowerCase();
    if (command.isEmpty) return;
    setState(() {
      if (command.contains('jam') || command.contains('waktu')) {
        final now = DateTime.now();
        _response = 'Waktu perangkat: ${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
      } else if (command.contains('bantuan') || command.contains('help')) {
        _response = 'Aku bisa menampilkan waktu, membuka panel layanan darurat, dan mengganti warna tema. Untuk panggilan darurat, gunakan tombol Layanan Darurat dan pastikan nomor sesuai wilayahmu.';
      } else if (command.contains('warna') || command.contains('tema')) {
        _response = 'Tema bisa diganti melalui pilihan warna di bawah.';
      } else {
        _response = 'Perintah diterima: "$command". Fitur ini berjalan lokal; belum terhubung ke layanan online.';
      }
    });
    _controller.clear();
  }

  @override
  Widget build(BuildContext context) {
    final colors = <String, Color>{
      'Mint': const Color(0xFF00E5C3),
      'Blue': const Color(0xFF65A8FF),
      'Purple': const Color(0xFFB48CFF),
      'Amber': const Color(0xFFFFC857),
    };
    final accent = colors[_accent]!;
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [
          Icon(Icons.auto_awesome, color: Color(0xFF00E5C3)),
          SizedBox(width: 10),
          Text('AHZA ASISTANT', style: TextStyle(fontWeight: FontWeight.w800)),
        ]),
        actions: [
          IconButton(
            tooltip: 'Tentang',
            onPressed: () => showAboutDialog(
              context: context,
              applicationName: 'AHZA ASISTANT',
              applicationVersion: '1.0.0',
              children: const [Text('Credit by LUA/AHZA • TikTok @luahub.kali')],
            ),
            icon: const Icon(Icons.info_outline),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [accent.withOpacity(.22), const Color(0xFF17263A)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: accent.withOpacity(.35)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('ASISTEN KOMUNITAS', style: TextStyle(letterSpacing: 2, color: Colors.white70)),
                  const SizedBox(height: 12),
                  const Text('Halo, AHZA!', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  const Text('Alat bantu lokal dengan antarmuka modern.'),
                  const SizedBox(height: 18),
                  Row(children: [
                    Icon(Icons.circle, size: 9, color: accent),
                    const SizedBox(width: 8),
                    const Text('Siap digunakan', style: TextStyle(color: Colors.white70)),
                  ]),
                ],
              ),
            ),
            const SizedBox(height: 18),
            const Text('PANEL CEPAT', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.4)),
            const SizedBox(height: 10),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 1.45,
              children: [
                _ToolCard(icon: Icons.access_time, title: 'Waktu', subtitle: 'Jam perangkat', color: accent, onTap: () => _runCommand('jam')),
                _ToolCard(icon: Icons.emergency, title: 'Layanan Darurat', subtitle: 'Nomor bantuan', color: Colors.orangeAccent, onTap: _showEmergency),
                _ToolCard(icon: Icons.palette_outlined, title: 'Tema', subtitle: 'Atur aksen warna', color: Colors.purpleAccent, onTap: _showThemes),
                _ToolCard(icon: Icons.help_outline, title: 'Bantuan', subtitle: 'Panduan singkat', color: Colors.lightBlueAccent, onTap: () => _runCommand('help')),
              ],
            ),
            const SizedBox(height: 18),
            const Text('CHAT ASISTEN', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.4)),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: const Color(0xFF132237), borderRadius: BorderRadius.circular(18)),
              child: Text(_response, style: const TextStyle(fontSize: 15, height: 1.45)),
            ),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(
                child: TextField(
                  controller: _controller,
                  onSubmitted: (_) => _runCommand(),
                  decoration: InputDecoration(
                    hintText: 'Ketik perintah...',
                    filled: true,
                    fillColor: const Color(0xFF132237),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filled(
                style: IconButton.styleFrom(backgroundColor: accent, foregroundColor: Colors.black),
                onPressed: _runCommand,
                icon: const Icon(Icons.send),
              ),
            ]),
            const SizedBox(height: 22),
            Center(child: Text('Credit by LUA/AHZA  •  TikTok @luahub.kali', style: TextStyle(color: Colors.white.withOpacity(.55), fontSize: 12))),
          ],
        ),
      ),
    );
  }

  void _showEmergency() {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      backgroundColor: const Color(0xFF132237),
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: const [
            Text('Layanan darurat', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text('Indonesia: 112 (darurat umum), 110 (Polisi), 119 (layanan medis), 113 (Pemadam Kebakaran). Ketersediaan dapat berbeda menurut wilayah.'),
            SizedBox(height: 14),
            Text('Gunakan fitur panggilan perangkat secara langsung dan verifikasi nomor lokal sebelum menghubungi.'),
          ]),
        ),
      ),
    );
  }

  void _showThemes() {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: ['Mint', 'Blue', 'Purple', 'Amber'].map((name) => ListTile(
          leading: const Icon(Icons.color_lens_outlined),
          title: Text(name),
          trailing: _accent == name ? const Icon(Icons.check) : null,
          onTap: () { setState(() => _accent = name); Navigator.pop(context); },
        )).toList()),
      ),
    );
  }
}

class _ToolCard extends StatelessWidget {
  const _ToolCard({required this.icon, required this.title, required this.subtitle, required this.color, required this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => InkWell(
    borderRadius: BorderRadius.circular(18),
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(color: const Color(0xFF132237), borderRadius: BorderRadius.circular(18), border: Border.all(color: color.withOpacity(.2))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, color: color, size: 27),
        const SizedBox(height: 9),
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 3),
        Text(subtitle, style: const TextStyle(color: Colors.white60, fontSize: 12)),
      ]),
    ),
  );
}
